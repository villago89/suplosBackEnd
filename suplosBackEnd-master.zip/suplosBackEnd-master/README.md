# suplosBackEnd
Prueba suplos desarrollador backend
# DataAcces.php 
Datos de Conexión a MOTOR de BD y Sentencias  DML , funciones 
# Intelcost_bienes.sql
Dump/Backup de la base de datos.

