/*
  Creación de una función personalizada para jQuery que detecta cuando se detiene el scroll en la página
*/
$.fn.scrollEnd = function(callback, timeout) {
  $(this).scroll(function(){
    var $this = $(this);
    if ($this.data('scrollTimeout')) {
      clearTimeout($this.data('scrollTimeout'));
    }
    $this.data('scrollTimeout', setTimeout(callback,timeout));
  });
};
/*
  Función que inicializa el elemento Slider
*/

function inicializarSlider(){
  $("#rangoPrecio").ionRangeSlider({
    type: "double",
    grid: false,
    min: 0,
    max: 100000,
    from: 200,
    to: 80000,
    prefix: "$"
  });
}
/*
  Función que reproduce el video de fondo al hacer scroll, y deteiene la reproducción al detener el scroll
*/
function playVideoOnScroll(){
  var ultimoScroll = 0,
      intervalRewind;
  var video = document.getElementById('vidFondo');
  $(window)
    .scroll((event)=>{
      var scrollActual = $(window).scrollTop();
      if (scrollActual > ultimoScroll){
       
     } else {
        //this.rewind(1.0, video, intervalRewind);
        //video.play();
     }
     ultimoScroll = scrollActual;
    })
    .scrollEnd(()=>{
      //video.pause();
    }, 10)
}

inicializarSlider();
playVideoOnScroll();

function comboSelect(){
        $.ajax({
            type: "POST",
            url: "DataAccess",
            async: false,
            data: { funcion: 'comboSelect'}
        })
        .done(function( r ) {
            if(r.response==true){
                $("#selectCiudad").html(r.ciudades);
                $("#selectTipo").html(r.tipos);
                $("#selectCiudadR").html(r.ciudades);
                $("#selectTipoR").html(r.tipos);
            }else{
                swal("Error", r.message, "error");
            }
        })
        .fail(function( jqXHR, textStatus ) {
            swal("Error", "Request failed " + jqXHR.statusText, "error");
        });
    }

    function bienesDisponibles(comprados){
        form = $("#formulario").serialize();
        $.ajax({
            type: "POST",
            url: "DataAccess",
            async: false,
            data: { funcion: 'bienesDisponibles',comprados: comprados,form}
        })
        .done(function( r ) {
            if(r.response==true){
                if(comprados==0)
                    $("#divResultadosBienes").html(r.data);
                else
                    $("#divResultadosBusqueda").html(r.data);
            }else{
                swal("Error", r.message, "error");
            }
        })
        .fail(function( jqXHR, textStatus ) {
            swal("Error", "Request failed " + jqXHR.statusText, "error");
        });
    }

    function guardar(id){
        $.ajax({
            type: "POST",
            url: "DataAccess",
            async: false,
            data: { funcion: 'guardar',id: id}
        })
        .done(function( r ) {
            if(r.response==true){
                swal("OK", r.message, "success");
                bienesDisponibles(0);
            }else{
                swal("Error", r.message, "error");
            }
        })
        .fail(function( jqXHR, textStatus ) {
            swal("Error", "Request failed " + jqXHR.statusText, "error");
        });
    }

    function eliminar(id){
        $.ajax({
            type: "POST",
            url: "DataAccess",
            async: false,
            data: { funcion: 'eliminar',id: id}
        })
        .done(function( r ) {
            if(r.response==true){
                swal("OK", r.message, "success");
                bienesDisponibles(1);
            }else{
                swal("Error", r.message, "error");
            }
        })
        .fail(function( jqXHR, textStatus ) {
            swal("Error", "Request failed " + jqXHR.statusText, "error");
        });
    }


    function misBienes(){
        $('#selectCiudad').val("");
        $('#selectTipo').val("");
       bienesDisponibles(1) ;
       $("#submitButton").attr("value","Buscar Mis Bienes");
       $("#submitButton").attr("onclick","bienesDisponibles(1)");
    }
    function disponibles(){
        $('#selectCiudad').val("");
        $('#selectTipo').val("");
       bienesDisponibles(0) ;
       $("#submitButton").attr("value","Buscar Bienes Disponibles");
       $("#submitButton").attr("onclick","bienesDisponibles(0)");
    }


