<?php
class DataAccess{
    var $Conexion_ID = false;
    function __construct(){
        $_host = "localhost";
        $_user = "desarrollo";
        $_pass = "control";
        $_bdname = "Intelcost_bienes";
        $this->Conexion_ID = new mysqli($_host,  $_user, $_pass, $_bdname);
        if (!$this->Conexion_ID){
            $this->Error = "Ha fallado la conexión.";
            $response["response"] = false;
            $response["message"] = $this->Error;
            $response['data'] = $this->Conexion_ID;
            $this->showResponse($response, 200);
        }
    }

    public function showResponse($data, $estado) {
        header('Content-Type: application/json');
        echo json_encode( $data );

    }

    public function comboSelect(){
        $sql = "Select JSON_EXTRACT (etiquetas,'$.Tipo') as tipo from bienes group by 1";
        $reg  = $this->Conexion_ID->query($sql);
        $tipos = "<option value=''>Elige un tipo</option>";
        while($row=$reg->fetch_assoc()){
            $row['tipo'] = trim(str_replace('"',"",$row['tipo'])); 
            $tipos .= "<option value = '{$row['tipo']}'>{$row['tipo']}</option>";
        }
        $sql = "Select JSON_EXTRACT (etiquetas,'$.Ciudad') as ciudad from bienes group by 1";
        $reg  = $this->Conexion_ID->query($sql);
        $ciudades = "<option value=''>Elige una ciudad</option>";
        while($row=$reg->fetch_assoc()){
            $row['ciudad'] = trim(str_replace('"'," ",$row['ciudad'])); 
            $ciudades .= "<option value = '{$row['ciudad']}' >{$row['ciudad']}</option>";
        }
        $response["response"] = true;
        $response["message"] = "";
        $response['ciudades'] = $ciudades;
        $response['tipos'] = $tipos;
        $this->showResponse($response, 200);
    }

    function bienesDisponibles(){
        $comprados = $_POST['comprados'];
        parse_str($_POST["form"], $searcharray);
        if($comprados == 0){
            $sql = "Select bienes.* from bienes  left join bienes_comprados on bienes.id = bienes_comprados.id where bienes_comprados.id is null";
            $table = "bienes";
        }else{
            $sql = "Select * from bienes_comprados where 1=1 ";
            $table = "bienes_comprados";
        }
        $ciudad = $searcharray['ciudad'];
        $tipo = $searcharray['tipo'];
        $conditions = array();
        if($ciudad != ""){
            $conditions[] = "JSON_EXTRACT($table.etiquetas, '$.Ciudad') = '$ciudad'";
        }
        if($tipo != ""){
            $conditions[] = "JSON_EXTRACT($table.etiquetas, '$.Tipo') = '$tipo'";
        }
        $conditions = count($conditions) > 0 ? JOIN(" AND ",$conditions) : "1=1 ";
        $sql .= " AND $conditions ";

        $reg  = $this->Conexion_ID->query($sql);
        if (!$reg) {
            $response["response"] = false;
            $response["message"] = $this->Conexion_ID->errno." ".$this->Conexion_ID->error;
            $this->showResponse($response, 200);
            return ;
        }
        if($comprados == 0 )
             $html = '<div class="tituloContenido card" style="justify-content: center;"> <h5>Resultados de la búsqueda: '.$reg->num_rows.'</h5>';
        else
             $html = '<div class="tituloContenido card" style="justify-content: center;"> <h5>Bienes Comprados: '.$reg->num_rows.'</h5>';
        $html .= '<div class="col s12 divider">';
        while($row=$reg->fetch_assoc()){
            $html .= '<div class="row">';
            $html .= '<div class="col s6">';
            $html .= '<img src="img/home.jpg" width="100%" heigth= "100%" alt="MDN" >';
            $html .= '</div>'; 
            $html .= '<div class="col s6">';
            foreach(json_decode($row['etiquetas']) as $key => $value){
                if($key == "Id") continue;
                $html .= "<div class='row'>";
                $html .= "<div class='col s12'><label>$key:</label> $value</div>";
                $html .= "</div>";
            }
            $html .= "<div class='row'>";
            if($comprados == 0)
                $html .= "<div class='col s12 m12 l2 input-field'><a  onclick = 'guardar({$row['id']})' class='waves-effect waves-light btn blue'>Comprar</a></div>";
            else
                $html .= "<div class='col s12 m12 l2 input-field'><a  onclick = 'eliminar({$row['id']})' class='waves-effect waves-light btn red'>Vender</a></div>";
            $html .= "</div>"; 
            $html .= "</div>"; 
            $html .= "<hr/>";
            $html .= "</div>"; 
        }
        $html .= '</div>'; 
        $html .= '</div>'; 
        $response["response"] = true;
        $response["message"] = "";
        $response['data'] = $html;
        $this->showResponse($response, 200);
    }

    public function guardar(){
        $id = $_POST['id'];
        $sql = "insert into bienes_comprados select * from bienes where id = $id";
        $reg  = $this->Conexion_ID->query($sql);
         if (!$reg) {
            $response["response"] = false;
            $response["message"] = $this->Conexion_ID->errno." ".$this->Conexion_ID->error;
            $this->showResponse($response, 200);
            return ;
        }
        $response["response"] = true;
        $response["message"] = "La compra fue  exitosa.";
        $this->showResponse($response, 200);
    }


    public function eliminar(){
        $id = $_POST['id'];
        $sql = "delete from bienes_comprados where id = $id";
        $reg  = $this->Conexion_ID->query($sql);
        if (!$reg) {
            $response["response"] = false;
            $response["message"] = $this->Conexion_ID->errno." ".$this->Conexion_ID->error;
            $this->showResponse($response, 200);
            return ;
        }
        $response["response"] = true;
        $response["message"] = "La venta fue exitosa.";
        $this->showResponse($response, 200);
    }

    public function reporte(){
        require_once "Library/Excel/Main.php";
        $excels = new Spreadsheet_Excel_Writer();
        $excel = $excels->addWorksheet();
        $comprados = $_POST['compradosR'];
        $ciudad = $_POST['ciudadR'];
        $tipo = $_POST['tipoR'];
        $column_title = $excels->addFormat(array('fontfamily' => 'Verdana',
                    'size' => 12,
                    'fgcolor' => 13,
                    'border' => 1,
                    'bordercolor' => 'black',
                    "halign" => 'center'
                    ));
        $title = $excels->addFormat(array(   'fontfamily' => 'Verdana',
                    'size' => 13,
                    'border' => 0,
                    'bordercolor' => 'black',
                    "halign" => 'center'
                    ));
        $column_style = $excels->addFormat(array(   'fontfamily' => 'Verdana',
                    'size' => 11,
                    'border' => 1,
                    'bordercolor' => 'black',
                    "halign" => 'left'
                    ));
        $excel->setMerge(0,1,0,6);
        $row = 0;
        $excel->write($row++, 0, date('Y-m-d')."-".date('H:i:s'));
        $excel->write($row++, 0, "BIENES INTELCOST");
        if($comprados == 0){
            $excel->write($row++,3,'Reporte De Bienes Disponibles',$title);
            $sql = "Select bienes.* from bienes  left join bienes_comprados on bienes.id = bienes_comprados.id where bienes_comprados.id is null";
            $table = "bienes";
            $file = "BIENES_DISPONIBLES.xls";
        }else{
            $excel->write($row++,3,'Reporte De Bienes Comprados',$title);
            $sql = "Select * from bienes_comprados where 1=1 ";
            $file = "BIENES_COMPRADOS.xls";
            $table = "bienes_comprados";
        }
        $conditions = array();
        if($ciudad != ""){
            $conditions[] = "JSON_EXTRACT($table.etiquetas, '$.Ciudad') = '$ciudad'";
        }
        if($tipo != ""){
            $conditions[] = "JSON_EXTRACT($table.etiquetas, '$.Tipo') = '$tipo'";
        }
        $conditions = count($conditions) > 0 ? JOIN(" AND ",$conditions) : "1=1 ";
        $sql .= " AND $conditions ";

        $reg  = $this->Conexion_ID->query($sql);
        if (!$reg) {
            $response["response"] = false;
            $response["message"] = $this->Conexion_ID->errno." ".$this->Conexion_ID->error;
            $this->showResponse($response, 200);
            return ;
        }
        $excel->setColumn(0,0,15);
        $excel->setColumn(1,1,45);
        $excel->setColumn(2,2,45);
        $excel->setColumn(3,3,45);
        $excel->setColumn(4,4,45);
        $excel->setColumn(5,5,45);
        $excel->setColumn(6,6,45);
        $j = true;
        while($fields=$reg->fetch_assoc()){
            $i=0;
            if($j==true){
                foreach(json_decode($fields['etiquetas']) as $key => $value){
                    $excel->write($row, $i++, $key, $column_title);
                }
                $j = false;
                $i=0;
            }
            $row++;
            foreach(json_decode($fields['etiquetas']) as $key => $value){
                $excel->write($row, $i++, $value, $column_style);
            }
        }

        ob_end_clean();
        $excels->send($file);
        $excels->close();
    }

}

$data = new DataAccess();
$function = $_POST['funcion'];
$data->$function();

?>
